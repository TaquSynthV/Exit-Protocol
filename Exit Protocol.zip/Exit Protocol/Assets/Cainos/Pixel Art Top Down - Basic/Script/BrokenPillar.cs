using UnityEngine;

public class BrokenPillar : MonoBehaviour, IInteractable
{
    public GameObject fixedPillarPrefab; // �C����̃v���n�u

    private bool isFixed = false;

    public void Interact()
    {
        if (isFixed) return;

        if (GameManager.Instance.stoneCount >= 6)
        {
            isFixed = true;
            Debug.Log("�Α����C�������I");

            Instantiate(fixedPillarPrefab, transform.position, transform.rotation);
            Destroy(gameObject);
        }
        else
        {
            Debug.Log("�΂�����Ȃ��c�i" + GameManager.Instance.stoneCount + " / 6�j");
        }
    }
}
